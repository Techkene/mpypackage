# My Package
This is a library I created following explore AI directions